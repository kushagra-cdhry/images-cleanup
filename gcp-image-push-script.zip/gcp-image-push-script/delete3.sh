#!/bin/bash

# Set variables
PROJECT_ID="your-gcp-project-id"  # Replace with your GCP project ID
KEEP=10  # Number of versions to retain
LOCATION="asia-south1"  # Specify the single location

echo "Processing location: $LOCATION"

# Fetch repositories from Artifact Registry in the specified location
repositories=$(gcloud artifacts repositories list --project="$PROJECT_ID" --location="$LOCATION" --format="value(name)")

echo "Repositories fetched in $LOCATION: $repositories"

# Check if repositories are empty
if [ -z "$repositories" ]; then
    echo "  No repositories found in $LOCATION. Exiting."
    exit 0
fi

# Loop through each repository
for repo_name in $repositories; do
    echo "  Processing repository: $repo_name"

    # Fetch package names and their versions
    packages=$(gcloud artifacts docker images list "$LOCATION-docker.pkg.dev/$PROJECT_ID/$repo_name" --format="value(name,updateTime)" | sort -k2 -r)

    echo "  Packages fetched for $repo_name: $packages"

    # Skip if no packages are found
    if [ -z "$packages" ]; then
        echo "  No packages found in $repo_name. Skipping."
        continue
    fi

    # Clear previous data for each repo
    unset package_versions
    declare -A package_versions

    # Populate associative array with package names and their versions
    while read -r package update_time; do
        package_name="${package%:*}"  # Get package name without version
        package_versions["$package"]="$update_time"
    done <<< "$packages"

    # Sort packages by update times (most recent first)
    sorted_packages=($(for package in "${!package_versions[@]}"; do 
                          echo "$package ${package_versions[$package]}"; 
                       done | sort -k2 -r | awk '{print $1}'))

    echo "  Sorted packages for $repo_name: ${sorted_packages[*]}"

    # Check if we have more versions than we need to keep
    if (( ${#sorted_packages[@]} > KEEP )); then
        # Find old versions to delete
        packages_to_delete=("${sorted_packages[@]:KEEP}")  # This keeps the latest versions
        echo "  Deleting old versions from $repo_name: ${packages_to_delete[*]}"

        # Delete each old version
        for package in "${packages_to_delete[@]}"; do
            echo "  Deleting package: $package from $repo_name"
            # gcloud artifacts docker images delete "$package" --quiet
            echo "  Deleted package: $package from $repo_name"
        done
    else
        echo "  No old versions to delete. Keeping all ${#sorted_packages[@]} versions."
    fi
done
