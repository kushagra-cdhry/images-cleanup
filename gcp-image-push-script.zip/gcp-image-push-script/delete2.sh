#!/bin/bash

# GCP project ID
PROJECT_ID="tough-volt-437004-e3"

# Specify the number of images to keep
KEEP=10  # Change this value to specify how many images to retain

# Specify the desired locations in an array
LOCATIONS=("asia-south1" "asia-south2" "europe-west1")  # Add more locations as needed

# Loop through each specified location
for LOCATION in "${LOCATIONS[@]}"; do
    # List all repositories in the specified location
    REPOS=$(gcloud artifacts repositories list --project="$PROJECT_ID" \
            --location="$LOCATION" --format="value(name)" --quiet 2>/dev/null)

    # Check for errors in the command
    if [ $? -ne 0 ]; then
        echo "Error: Unable to list repositories for location $LOCATION."
        continue
    fi

    # Print repositories found in the current location only if there are any
    if [ -n "$REPOS" ]; then
        echo "Repositories Found in $LOCATION:"
        
        # Loop through each repository
        echo "$REPOS" | while read -r REPO; do
            echo "  - $REPO"

            # Construct the full image path
            IMAGE_PATH="$LOCATION-docker.pkg.dev/$PROJECT_ID/$REPO"

            # List all images in the repository with their update time, sorted by latest update first
            IMAGES=$(gcloud artifacts docker images list "$IMAGE_PATH" \
                    --format="value(IMAGE, updateTime)" | sort -k2 -r)

            # Check if there are any images
            if [ $? -eq 0 ] && [ -n "$IMAGES" ]; then
                echo "    Images found in $REPO:"
                
                # Create an array to hold unique images
                IMAGE_ARRAY=()  # Clear the array for the new repository
                while read -r IMAGE UPDATE_TIME; do
                    # Extract only the last part of the image name
                    IMAGE_NAME=$(basename "$IMAGE")

                    # Check if the image is already in the list
                    if [[ ! " ${IMAGE_ARRAY[@]} " =~ " ${IMAGE_NAME} " ]]; then
                        IMAGE_ARRAY+=("$IMAGE_NAME")  # Add to array if not already present
                    fi
                done <<< "$IMAGES"

                # Count of unique images found
                IMAGE_COUNT=${#IMAGE_ARRAY[@]}
                echo "    Unique images found: $IMAGE_COUNT"

                # Retain only the latest images as per KEEP variable
                if [ "$IMAGE_COUNT" -gt "$KEEP" ]; then
                    IMAGES_TO_DELETE=("${IMAGE_ARRAY[@]:$KEEP}")  # Get images to delete
                    IMAGE_ARRAY=("${IMAGE_ARRAY[@]:0:$KEEP}")  # Keep only latest $KEEP images
                    
                    echo "      Retained Images:"
                    for IMAGE_NAME in "${IMAGE_ARRAY[@]}"; do
                        echo "      - $IMAGE_NAME"
                    done

                    echo "      Images to be deleted:"
                    for IMAGE_NAME in "${IMAGES_TO_DELETE[@]}"; do
                        echo "      - $IMAGE_NAME"
                    done

                    # Uncomment the following line to actually delete the images
                    for IMAGE_NAME in "${IMAGES_TO_DELETE[@]}"; do
                        echo "      Deleting $IMAGE_NAME..."
                        gcloud artifacts docker images delete "$IMAGE_PATH/$IMAGE_NAME" --quiet
                    done
                else
                    echo "    No images to delete. Found $IMAGE_COUNT unique images:"
                    for IMAGE_NAME in "${IMAGE_ARRAY[@]}"; do
                        echo "      - $IMAGE_NAME"
                    done
                fi
            else
                echo "    No images found in $REPO."
            fi
        done
    else
        echo "    No repositories found in $LOCATION."
    fi
done
