#!/bin/bash

# Set variables
PROJECT_ID="tough-volt-437004-e3"
REGION="asia-south1" # Specify the region
REPOSITORY="sample-repo-4" # Specify the repository

# Function to list images and their tags sorted by update time
list_image_tags_sorted() {
    local repository="$1"

    # List all images in the specified repository
    IMAGES=$(gcloud artifacts docker images list "$REGION-docker.pkg.dev/$PROJECT_ID/$repository" --format="value(IMAGE)" --quiet)

    # Check for errors in the command
    if [ $? -ne 0 ]; then
        echo "Error: Unable to list images in repository $repository."
        return
    fi

    # Check if any images are found
    if [ -z "$IMAGES" ]; then
        echo "No images found in the repository $repository."
        return
    fi

    # Loop through each image
    for image in $IMAGES; do
        # Extract basename
        BASENAME="${image##*/}" # Get the image basename
        echo "Found image basename: $BASENAME"

        # List all tags of the current image and sort them by update time (recent first)
        TAGS=$(gcloud artifacts tags list \
                    --project="$PROJECT_ID" \
                    --repository="$repository" \
                    --location="$REGION" \
                    --package="$BASENAME" \
                    --format="value(TAG, TIMESTAMP)" \
                    --sort-by=~TIMESTAMP)

        # Check for errors in the command
        if [ $? -ne 0 ]; then
            echo "Error: Unable to list tags for image $BASENAME."
            continue
        fi

        # Print tags
        if [ -z "$TAGS" ]; then
            echo "No tags found for image $BASENAME."
        else
            echo "$TAGS"
        fi

        echo ""
    done
}

# Call the function to list image tags
list_image_tags_sorted "$REPOSITORY"

echo "All image basenames and their tags have been listed successfully!"
