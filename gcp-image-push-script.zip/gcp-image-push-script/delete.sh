#!/bin/bash

# Set variables
PROJECT_ID="your-gcp-project-id"  # Replace with your GCP project ID
KEEP=0  # Number of images to retain per repository
LOCATIONS=("asia-south1" "asia-south2" "europe-west1")  # Specify your locations

# Loop through each specified location
for LOCATION in "${LOCATIONS[@]}"; do
    echo "Processing location: $LOCATION"

    # Fetch repositories from Artifact Registry in the specified location
    repositories=$(gcloud artifacts repositories list --project="$PROJECT_ID" --location="$LOCATION" --format="value(name)")

    echo "Repositories fetched in $LOCATION: $repositories"

    # Loop through each repository
    for repo_name in $repositories; do
        echo "  Processing repository: $repo_name"

        # Construct the full image path
        IMAGE_PATH="$LOCATION-docker.pkg.dev/$PROJECT_ID/$repo_name"

        # Fetch image tags and update times for the repository
        images=$(gcloud artifacts docker images list "$IMAGE_PATH" --format="value(name,updateTime)" | sort -k2 -r)

        echo "  Images fetched for $repo_name: $images"

        # Skip if no images are found
        if [ -z "$images" ]; then
            echo "  No images found in $repo_name. Skipping."
            continue
        fi

        # Clear previous data for each repo
        unset image_dates
        declare -A image_dates

        # Populate associative array with image tags and update times
        while read -r tag update_time; do
            image_dates["$tag"]="$update_time"
        done <<< "$images"

        # Sort images by update times (most recent first)
        sorted_tags=($(for tag in "${!image_dates[@]}"; do 
                          echo "$tag ${image_dates[$tag]}"; 
                       done | sort -k2 -r | awk '{print $1}'))

        echo "  Sorted images for $repo_name: ${sorted_tags[*]}"

        # Check if we have more images than we need to keep
        if (( ${#sorted_tags[@]} > KEEP )); then
            # Find old images to delete
            images_to_delete=("${sorted_tags[@]:KEEP}")
            echo "  Deleting old images from $repo_name: ${images_to_delete[*]}"

            # Delete each old image
            for image in "${images_to_delete[@]}"; do
                echo "  Deleting image: $image from $repo_name"
                gcloud artifacts docker images delete "$image" --quiet
                echo "  Deleted image: $image from $repo_name"
            done
        else
            echo "  No old images to delete. Keeping all ${#sorted_tags[@]} images."
        fi
    done
done
